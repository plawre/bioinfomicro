# UNCW Marine Bioinformatics Workshop — Materials

This repository hosts the public tutorials and small helper files for the workshop series.  
**Site:** enabled via GitHub Pages from the `/docs` folder.

- Landing page: `docs/index.md`
- Week 0 tutorial: `docs/W0.md`
- Minimal Conda env: `env/biotot-min.yml`

To view the website after enabling Pages: `https://<your-username>.github.io/<this-repo>/`
